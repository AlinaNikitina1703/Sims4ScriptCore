import collections
import time

import alarms
import animation
import autonomy
import autonomy.autonomy_component
import autonomy.autonomy_service
import autonomy.settings
import date_and_time
import element_utils
import services
from animation.arb_accumulator import ArbAccumulatorService, _get_actors_for_arb_element_sequence, \
    AnimationSleepElement, ArbSequenceElement
from time_service import TimeService

from scripts_core.sc_util import error_trap

MAX_DISTANCE_SCORE = 10
FULL_AUTONOMY_MULTIPLIER = 1
MULTIPLIER_FOR_HOUSEHOLD_SIMS = 1
last_updated_sim_priorities = time.time()
update_autonomy = 1
last_updated_real_time = collections.defaultdict(time.time)
failed_full_autonomy = {}
successful_full_autonomy_times = collections.defaultdict(time.time)
last_obj = None
autonomy_distance_cutoff = 10
current_sims_full_autonomy_limit = 2 * autonomy_distance_cutoff
max_full_autonomy_sims_if_someone_is_pickupping_something = 1 * autonomy_distance_cutoff
max_full_autonomy_sims_when_normal = 2 * autonomy_distance_cutoff

sim_buffer = 1.0
sim_delay = date_and_time.TimeSpan(1)

old_run_gen = ArbSequenceElement._run_gen
old_run_full_autonomy_callback_gen = autonomy.autonomy_component.AutonomyComponent._run_full_autonomy_callback_gen
old_create_full_autonomy_alarm = autonomy.autonomy_component.AutonomyComponent._create_full_autonomy_alarm

# default is 25
# date_and_time.REAL_MILLISECONDS_PER_SIM_SECOND = 250
TimeService.MAX_TIME_SLICE_MILLISECONDS = 8

def set_distance_score(score=10):
    global MAX_DISTANCE_SCORE
    MAX_DISTANCE_SCORE = int(score)

def set_autonomy_mult(mult=5):
    global autonomy_distance_cutoff, current_sims_full_autonomy_limit
    global max_full_autonomy_sims_if_someone_is_pickupping_something, max_full_autonomy_sims_when_normal
    autonomy_distance_cutoff = int(mult)
    current_sims_full_autonomy_limit = 2 * autonomy_distance_cutoff
    max_full_autonomy_sims_if_someone_is_pickupping_something = 1 * autonomy_distance_cutoff
    max_full_autonomy_sims_when_normal = 2 * autonomy_distance_cutoff

def set_time_slice(slice=8):
    TimeService.MAX_TIME_SLICE_MILLISECONDS = slice
    time_service = services.time_service()
    time_service.update()

def set_speed_of_time(speed=250):
    date_and_time.REAL_MILLISECONDS_PER_SIM_SECOND = speed

def set_sim_delay(delay: date_and_time.TimeSpan):
    global sim_delay
    sim_delay = delay

def set_sim_buffer(buffer=1.0):
    global sim_buffer
    sim_buffer = buffer

def set_update_autonomy(amount: int):
    global update_autonomy
    update_autonomy = amount

def _run_full_autonomy_callback_gen(self, timeline):
    global sim_delay
    try:
        try:
            autonomy_pushed_interaction = None
            self.set_last_autonomous_action_time(False)
            autonomy_pushed_interaction = yield from self._attempt_full_autonomy_gen(timeline)
            self._last_autonomy_result_was_none = not autonomy_pushed_interaction
            if autonomy_pushed_interaction:
                failed_full_autonomy[self.owner] = True
            else:
                failed_full_autonomy[self.owner] = False
                successful_full_autonomy_times[self.owner.id] = time.time()
        except Exception:
            pass
    finally:
        self._full_autonomy_element_handle = None
        self._schedule_next_full_autonomy_update(sim_delay)

    if False:
        yield None

def _create_full_autonomy_alarm(self, time_until_trigger):
    global sim_delay
    if self._full_autonomy_alarm_handle is not None:
        self._destroy_full_autonomy_alarm()
    time_until_trigger = sim_delay
    self._full_autonomy_alarm_handle = alarms.add_alarm(self, time_until_trigger, (self._on_run_full_autonomy_callback), use_sleep_time=False)

def arbs_run_gen(self, timeline):
    try:
        global sim_buffer, old_run_gen
        if not self._arb_element_sequence:
            return True
        duration_must_run = 0.0
        duration_interrupt = 0.0
        duration_repeat = 0.0
        for arb_element in self._arb_element_sequence:
            arb_duration_total, arb_duration_must_run, arb_duration_repeat = arb_element.arb.get_timing()
            arb_duration_interrupt = arb_duration_total - arb_duration_must_run
            duration_must_run += arb_duration_must_run * sim_buffer
            arb_element.distribute()

            duration_interrupt = arb_duration_interrupt
            duration_repeat = arb_duration_repeat
            if ArbAccumulatorService.MAXIMUM_TIME_DEBT > 0:
                actors = _get_actors_for_arb_element_sequence((self._arb_element_sequence), main_timeline_only=True)
                arb_accumulator = services.current_zone().arb_accumulator_service
                time_debt_max = arb_accumulator.get_time_debt(actors)
                shave_time_actual = arb_accumulator.get_shave_time_given_duration_and_debt(duration_must_run,
                                                                                           time_debt_max)
                duration_must_run -= shave_time_actual
                if shave_time_actual:
                    for actor in actors:
                        time_debt = arb_accumulator.get_time_debt((actor,))
                        time_debt += shave_time_actual
                        arb_accumulator.set_time_debt((actor,), time_debt)

                else:
                    last_arb = self._arb_element_sequence[(-1)].arb
                    if all((last_arb._normal_timeline_ends_in_looping_content(actor.id) for actor in actors)):
                        duration_must_run += time_debt_max
                        arb_accumulator.set_time_debt(actors, 0)
        else:
            arbs = tuple((animation_element.arb for animation_element in self._arb_element_sequence))
            animation_sleep_element = AnimationSleepElement(duration_must_run, duration_interrupt, duration_repeat,
                                                            arbs=arbs)
            try:
                if not self._animate_instantly:
                    yield from element_utils.run_child(timeline, animation_sleep_element)
            except:
                pass
            optional_time_elapsed = animation_sleep_element.optional_time_elapsed
            if ArbAccumulatorService.MAXIMUM_TIME_DEBT > 0 and optional_time_elapsed > 0:
                actors = animation.arb_accumulator.get_actors_for_arb_sequence()
                for actor in actors:
                    time_debt = animation.arb_accumulator.get_time_debt((actor,))
                    new_time_debt = time_debt - optional_time_elapsed
                    new_time_debt = max(new_time_debt, 0)
                    animation.arb_accumulator.set_time_debt((actor,), new_time_debt)

        return True
        if False:
            yield None
    except BaseException as e:
        error_trap(e)
        ArbSequenceElement._run_gen = old_run_gen

ArbSequenceElement._run_gen = arbs_run_gen
autonomy.autonomy_component.AutonomyComponent._run_full_autonomy_callback_gen = _run_full_autonomy_callback_gen
autonomy.autonomy_component.AutonomyComponent._create_full_autonomy_alarm = _create_full_autonomy_alarm

